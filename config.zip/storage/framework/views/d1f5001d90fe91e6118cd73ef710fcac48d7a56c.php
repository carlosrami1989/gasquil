 
 
        <table class="configTableCabecera">
            <tr>
                <th align="left" width="40px" ROWSPAN=3>
                <!-- <img src="<?php echo e(public_path('img/LogoCompleto.png')); ?>" borde="0" width="102px" height="50px" /> -->
                </th>
                <th align="center"><span> Benemerita Sociedad Protectora de la Infancia</span></th>
            </tr>
            <tr>
                <th align="center"><span>Club Rotario Astillero</span></th>
            </tr>
            <tr>
                <th align="center"><span>GUAYAQUIL</span></th>
            </tr>

        </table>
 
    
 
<table class="configTableCaberaAll configBorderItem configTextItem2 topCabecera" >
    <tr class="cabeceras" >
        <td>Nº registro</td>
        <td>Fecha de registro</td>
        <td>Descripcion de Desechos</td>
        <td>Responsable del área</td>
        <td>Departamento</td>
         
        <td>Kg.</td>
        
        
    </tr>
    <?php
    $cont = 0;
    ?>
    <?php for($i=0; $i < sizeof($lista) ; $i++): ?> <tr>
        <?php
        $cont = $i;
        $cont +=1;

        ?>
        <td   > <?php echo e($cont); ?></td>
        <td > <?php echo e($lista[$i]->created_at); ?></td>
               <td > <?php echo e($lista[$i]->des_clasificacion_desechos_des); ?></td>
        <td > <?php echo e($lista[$i]->responsable_apellido); ?> <?php echo e($lista[$i]->responsable_nombre); ?></td>
        <td > <?php echo e($lista[$i]->departamento); ?></td>
        
        <td > <?php echo e($lista[$i]->peso); ?></td>
        
       
       
        </tr>

        <?php endfor; ?>


</table>




<table style="position: fixed;bottom: 0px;">
    <thead>
        <tr>
            
        </tr>
    </thead>
</table>


 <?php /**PATH C:\inetpub\wwwroot\gestion_mantenimiento\resources\views/reports/excel_excel.blade.php ENDPATH**/ ?>