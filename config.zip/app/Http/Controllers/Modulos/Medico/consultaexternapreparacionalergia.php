<?php

namespace App\Http\Controllers\Modulos\Medico;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class consultaexternapreparacionalergia extends Controller
{
    //
}
