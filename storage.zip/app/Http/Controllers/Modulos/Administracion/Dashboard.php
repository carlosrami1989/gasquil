<?php

namespace App\Http\Controllers\Modulos\Administracion;

use App\Exports\LibriExport;
use App\Exports\LubriConsolidadoExport;
use App\Exports\LubriVentasStockExport;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;


use App\Models\Modulos\Parametrizacion\TbTipoDesecho;
use App\Models\Modulos\Parametrizacion\TbClasificacionDesecho;
use App\Models\Modulos\Parametrizacion\TbClasificacionDesechosDescripcion;
use App\Models\Modulos\Parametrizacion\tbResponsable;
use App\Models\Modulos\Parametrizacion\tb_lubricantes;
//use App\Models\Modulos\Parametrizacion­\tbIngresoInfo;
use App\Models\Modulos\Parametrizacion\tbIngresoInfo;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

use App\Models\Modulos\Parametrizacion\tb_consulta_dia;
use App\Models\Modulos\Parametrizacion\tb_consulta_mes;
use App\Models\Modulos\Parametrizacion\tb_estaciones;
use App\Models\Modulos\Parametrizacion\tb_gastos;
use App\Models\Modulos\Parametrizacion\tb_lubricantes_stock_esta;
use App\Models\Modulos\Parametrizacion\tb_lubricantes_stock_vent;


use App\Exports\UsersExport;
use Maatwebsite\Excel\Facades\Excel;

use App\Models\Modulos\Parametrizacion\tbUsuarioPerfil;
use Exception;

class Dashboard extends Controller
{
    public function ConsultarReporte($estacion, $fechadesde, $fechahasta)
    {
        try {

            $desde = date($fechadesde);
            $hasta = date($fechahasta);
            $mes = date("m", strtotime($fechadesde));
            $anio = date("Y", strtotime($fechadesde));
            
            if ($estacion == 0) {
                # code...
                $fecha_reporte = tb_lubricantes::DatosEstacion()
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->get();

                    $producto = tb_lubricantes::selectRaw("idProducto,DesProducto,SUM(Cantidad) as Total_cantidad,SUM(MontoDolaresDes) as Total_dolares")
                   
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->groupBy('idProducto', 'DesProducto')
                    ->orderby('Total_cantidad', 'desc')
                    ->get();

                    $productoVentaStock = tb_lubricantes_stock_esta::DatosEstacion()
                    ->where("idEstado", 1)
                    ->get();

                    // aqui va la agrupacion

                    // $productoVenta = tb_lubricantes_stock_vent::DatosEstacion()->where("mes", intval($mes))
                    // //->select(\DB::raw('SUBSTRING(DesProducto, 6, 0) as DesProducto_s'))
                    // ->where("anio", $anio)
                    // ->orderby('stock', 'desc')->get();
                    $productoVenta = tb_lubricantes_stock_vent::selectRaw("mes,anio,SUBSTRING(DesProducto, 1, 6) as codigop,SUM(stock) as stock,SUM(facturado) as facturado,SUM(total) as total")
                    ->where("mes", intval($mes))
                    ->where("anio", $anio)
                    ->groupBy('anio','mes', 'codigop')
                    ->orderby('stock', 'desc')
                    ->get();

                  

            } else {
                # code...
                $fecha_reporte = tb_lubricantes::DatosEstacion()
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->where('estacion', $estacion)
                    ->get();

                    $producto = tb_lubricantes::selectRaw("idProducto,DesProducto,estacion,SUM(Cantidad) as Total_cantidad,SUM(MontoDolaresDes) as Total_dolares")
                    ->DatosEstacion()
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->where('estacion', $estacion)
                    ->groupBy('estacion', 'idProducto', 'DesProducto')
                    ->orderby('estacion', 'desc')
                    ->orderby('Total_cantidad', 'desc')
                    ->orderby('Total_dolares', 'desc')
                    ->get();


                    $productoVentaStock = tb_lubricantes_stock_esta::DatosEstacion()
                    ->where("estacion", $estacion)
                    ->where("idEstado", 1)
                    ->get();

                    // $productoVenta = tb_lubricantes_stock_vent::DatosEstacion()->where("mes", intval($mes))
                    // ->where("anio", $anio)->where("estacion", $estacion)->orderby('stock', 'desc')->get();

                    $productoVenta = tb_lubricantes_stock_vent::selectRaw("mes,anio,SUBSTRING(DesProducto, 1, 6) as codigop,SUM(stock) as stock,SUM(facturado) as facturado,SUM(total) as total")
                    ->DatosEstacion()
                    ->where("estacion", $estacion)
                    ->where("mes", intval($mes))
                    ->where("anio", $anio)
                    ->groupBy('estacion','anio','mes', 'codigop')
                    ->orderby('stock', 'desc')
                    ->get();
        

            }



            return response()->json([
                'TotalesEstaciones' => $fecha_reporte,
                'TotalesEstacionesProducto' => $producto,
                'productoVentaStock' => $productoVentaStock,
                'productoVenta' => $productoVenta,
                // 'Vendedor' => $vendedor,

            ], 200);
        } catch (Exception $e) {
            return response()->json(['Resp' => $e->getMessage()], 500);
            //throw $th;
        }
    }
    public function ConsultarVendedorPorEstacion($mes, $anio)
    {
        try {

            $resultado = tb_lubricantes::selectRaw("mes,SUM(Cantidad) as Total_cantidad,SUM(MontoDolaresDes) as Total_dolares")
                ->DatosEstacion()
                ->where("mes", $mes)
                ->where("anio", $anio)
                ->groupBy('estacion', 'mes')
                ->orderby('Total_cantidad', 'desc')
                ->get();


            $vendedor = tb_lubricantes::selectRaw("Vendedor,SUM(MontoDolaresDes) as Total_dolares")
                ->DatosEstacion()
                ->where("mes", $mes)
                ->where("anio", $anio)
                ->groupBy('estacion', 'Vendedor')
                ->orderby('estacion', 'desc')
                ->orderby('Total_dolares', 'desc')
                ->get();

            $producto = tb_lubricantes::selectRaw("idProducto,DesProducto,estacion,SUM(Cantidad) as Total_cantidad,SUM(MontoDolaresDes) as Total_dolares")
                ->DatosEstacion()
                ->where("mes", $mes)
                ->where("anio", $anio)
                ->groupBy('estacion', 'idProducto', 'DesProducto')
                ->orderby('estacion', 'desc')
                ->orderby('Total_cantidad', 'desc')
                ->orderby('Total_dolares', 'desc')
                ->get();

            $vendedorPorEstacion = tb_lubricantes::selectRaw("idVendedor,Vendedor,estacion,SUM(MontoDolaresDes) as Total_dolares")
                ->DatosEstacion()
                ->where("mes", $mes)
                ->where("anio", $anio)
                ->groupBy('estacion', 'idVendedor', 'Vendedor')
                ->orderby('estacion', 'desc')
                ->get();
               

                $vendedorPorEstacionCantidad = tb_lubricantes::selectRaw("idVendedor,Vendedor,estacion, SUM(Cantidad) as Total_cantidad")
                ->DatosEstacion()
                ->where("mes", $mes)
                ->where("anio", $anio)
                ->groupBy('estacion', 'idVendedor', 'Vendedor')
                ->orderby('estacion', 'desc')

                ->get();




            $ListadoVendedor = $vendedorPorEstacion->groupBy('estacion')->map(function ($group, $groupName) {
                return [
                    'name' => $groupName,
                    'max' => $group->firstWhere('Total_dolares', $group->max('Total_dolares')),
                     

                ];
            });

            $ListadoVendedorCantidad = $vendedorPorEstacionCantidad->groupBy('estacion')->map(function ($group, $groupName) {
                return [
                    'name' => $groupName,
                    
                    'maxC' => $group->firstWhere('Total_cantidad', $group->max('Total_cantidad')),

                ];
            });

            $ListadoProducto = $producto->groupBy('estacion')->map(function ($group, $groupName) {
                return [
                    'name' => $groupName,
                    'max' => $group->firstWhere('Total_cantidad', $group->max('Total_cantidad')),
                    // 'maxC' => $group->firstWhere('Total_cantidad', $group->max('Total_cantidad')),

                ];
            });

            $ListadoProductoMin = $producto->groupBy('estacion')->map(function ($group, $groupName) {
                return [
                    'name' => $groupName,
                    'min' => $group->firstWhere('Total_cantidad', $group->min('Total_cantidad')),
                    // 'minC' => $group->firstWhere('Total_cantidad', $group->min('Total_cantidad')),

                ];
            });

            ///stock actualizado por ventas
           
            

            $vendedorPorEstacionTodos = tb_lubricantes::selectRaw("idVendedor,Vendedor,estacion,SUM(Cantidad) as Total_cantidad,SUM(MontoDolaresDes) as Total_dolares")
            ->DatosEstacion()
            ->where("mes", $mes)
            ->where("anio", $anio)
            ->groupBy('estacion', 'idVendedor', 'Vendedor')
            ->orderby('estacion', 'desc')
            ->orderby('Total_cantidad', 'desc')
            ->get();
        // $resultado =tb_consulta_mes::where("estacion",$estacion)->
        // where("mes",$mes)
        // ->get()->groupBy('mes');
        $ListadoVendedorTodos = $vendedorPorEstacionTodos->groupBy('estacion')->map(function ($group, $groupName) {
            return [
                'name' => $groupName,
                // 'max' => $group,
                'max' => $group->take(2),
            //  'maxC' => $group->firstWhere('Total_cantidad', $group->max('Total_cantidad')),
                 

            ];
        });

            return response()->json([
                'TotalesVendido' => $resultado,
                // 'Vendedor' => $vendedor,
                'productoMax' => $ListadoProducto,
                'productoMin' => $ListadoProductoMin,
                 'vendedorPorEstacion' => $vendedorPorEstacion,
                'vendedorPorEstacionCantidad' => $vendedorPorEstacionCantidad,
                 'ListadoVendedorCantidad' => $ListadoVendedorCantidad,
                'ListadoVendedor' => $ListadoVendedor,
                'vendedorPorEstacionTodos' => $vendedorPorEstacionTodos,
                'ListadoVendedorTodosMax' => $ListadoVendedorTodos,
                 
           
            ], 200);
        } catch (Exception $e) {
            return response()->json(['Resp' => $e->getMessage()], 500);
            //throw $th;
        }
    }
    public function ConsultarUsuario()
    {
        try {
            $user = Auth::user();


            return response()->json(['user' => $user], 200);

        } catch (Exception $e) {
            return response()->json(['msj' => $e->getMessage()], 500);
        }
    }
    public function User()
    {
        try {


            $resultado = User::All();


            return response()->json(['data' => $resultado], 200);
        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }
    //
    public function IncipSession($id)
    {
        try {


            $resultado = User::where("id", $id)->get();


            return response()->json(['data' => $resultado], 200);
        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }
    public function ConsultarInformacion()
    {
        try {


            $resultado = DB::select("call buscarDatos");


            return response()->json(['data' => $resultado], 200);
        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function ConsultarDatos()
    {

        try {
            $fecha = date('Y-m-d');
            $resultado = tbResponsable::all();

            $kilos_dia = tbIngresoInfo::whereDate('created_at', $fecha)->get();
            $kilos_total = tbIngresoInfo::all();





            return response()->json([
                'toal_registro' => $resultado->count(),
                'kilos_dia' => $kilos_dia->sum('peso'),
                'kilos_total' => $kilos_total->sum('peso')
            ], 200);
        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function ConsultarCalender($id)
    {
        try {


            $resultado = User::where("id", $id)->get();


            return response()->json(['data' => $resultado], 200);
        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function ConsultarMes($estacion, $mes, $anio)
    {
        try {

            if ($mes == 99) {
                # code...
                $resultado = tb_consulta_mes::where("estacion", $estacion)
                    ->where("anio", 2024)
                    ->get()->groupBy('mes');
            } else {

                $resultado = tb_consulta_mes::where("estacion", $estacion)->
                    where("mes", $mes)->
                    where("anio", $anio)
                    ->get();
            }

            // $resultado =tb_consulta_mes::where("estacion",$estacion)->
            // where("mes",$mes)
            // ->get()->groupBy('mes');



            return response()->json(['Resp' => $resultado], 200);
        } catch (Exception $e) {
            return response()->json(['Resp' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function ConsultarDia($estacion)
    {
        try {



            $resultado = tb_consulta_dia::where("estacion", $estacion)->get()->groupBy('dia');


            return response()->json(['Resp' => $resultado], 200);
        } catch (Exception $e) {
            return response()->json(['Resp' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function ConsultarEstaciones()
    {
        try {



            $resultado = tb_estaciones::all();


            return response()->json(['Resp' => $resultado], 200);
        } catch (Exception $e) {
            return response()->json(['Resp' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function ConsultarGastosEDS($estacion, $mes, $anio)
    {
        try {

            if ($estacion == 0) {
                $resultado = tb_gastos::where("mes", $mes)
                    ->where("anio", $anio)
                    ->get();
            } else {
                $resultado = tb_gastos::where("id_estacion", $estacion)
                    ->where("mes", $mes)
                    ->where("anio", $anio)
                    ->get();
            }




            return response()->json(['Resp' => $resultado], 200);
        } catch (Exception $e) {
            return response()->json(['Resp' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function ConsultarDiaPorEstacion($fecha)
    {
        try {

            $fecha_actual = date($fecha);
            //sumo 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "+ 1 days"));
            //resto 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "- 1 days"));

            # code...
            $resultado = tb_consulta_dia::selectRaw("dia,SUM(total) as total_dolares")
                ->selectRaw("SUM(galones) as galones")
                ->where('dia', '=', $fecha_actual)
                ->DatosEstacion()
                ->groupBy('estacion', 'dia')
                ->orderby('total_dolares', 'desc')
                ->get();

            // $resultado =tb_consulta_mes::where("estacion",$estacion)->
            // where("mes",$mes)
            // ->get()->groupBy('mes');



            return response()->json(['Resp' => $resultado], 200);
        } catch (Exception $e) {
            return response()->json(['Resp' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function createreporteExcel(Request $request)
    {

        //return  response()->json(['data' =>$request->all()], 200);
        try {

            $fecha_actual = date($request->fecha);
            //sumo 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "+ 1 days"));
            //resto 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "- 1 days"));

            # code...
            $resultado = tb_consulta_dia::selectRaw("dia,SUM(total) as total_dolares")
                ->selectRaw("SUM(galones) as galones")
                ->where('dia', '=', $fecha_actual)
                ->DatosEstacion()
                ->groupBy('estacion', 'dia')
                ->orderby('total_dolares', 'desc')
                ->get();


            $fecha = date('y-m-d');


            $nameExcel = 'Reporte Por Estacion Efectivo-' . $fecha . '.xls';
            //return  response()->json(['data' =>$resultado], 200);

            return Excel::download(
                new UsersExport($resultado, 'Reporte General de Desechos'),
                $nameExcel,
                header("Content-Type: application/vnd.ms-excel;")
            );





        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }
    public function createreporteExcelLubricantes(Request $request)
    {

        //return  response()->json(['data' =>$request->all()], 200);
        try {

            $fecha_actual = date($request->fecha);
            //sumo 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "+ 1 days"));
            //resto 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "- 1 days"));

            # code...
            $desde = date($request->desde);
            $hasta = date($request->hasta);

            if ($request->estacion == 0) {
                # code...
                $fecha_reporte = tb_lubricantes::DatosEstacion()
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->get();

                    $producto = tb_lubricantes::selectRaw("idProducto,DesProducto,SUM(Cantidad) as Total_cantidad,SUM(MontoDolaresDes) as Total_dolares")
                   
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->groupBy('idProducto', 'DesProducto')
                    ->orderby('Total_cantidad', 'desc')
                    ->get();


            } else {
                # code...
                $fecha_reporte = tb_lubricantes::DatosEstacion()
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->where('estacion', $request->estacion)
                    ->get();

                    $producto = tb_lubricantes::selectRaw("idProducto,DesProducto,estacion,SUM(Cantidad) as Total_cantidad,SUM(MontoDolaresDes) as Total_dolares")
                    ->DatosEstacion()
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->where('estacion', $request->estacion)
                    ->groupBy('estacion', 'idProducto', 'DesProducto')
                    ->orderby('estacion', 'desc')
                    ->orderby('Total_cantidad', 'desc')
                    ->orderby('Total_dolares', 'desc')
                    ->get();

            }

            $fecha = date('y-m-d');


            $nameExcel = 'Reporte Lubricacion Efectivo-' . $fecha . '.xls';
            //return  response()->json(['data' =>$resultado], 200);

            return Excel::download(
                new LibriExport($fecha_reporte, 'Reporte General de Desechos'),
                $nameExcel,
                header("Content-Type: application/vnd.ms-excel;")
            );





        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function createreporteExcelLubricantesConsolidado(Request $request)
    {

        //return  response()->json(['data' =>$request->all()], 200);
        try {

            $fecha_actual = date($request->fecha);
            //sumo 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "+ 1 days"));
            //resto 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "- 1 days"));

            # code...
            $desde = date($request->desde);
            $hasta = date($request->hasta);

            if ($request->estacion == 0) {
                # code...
               
                    $producto = tb_lubricantes::selectRaw("idProducto,DesProducto,SUM(Cantidad) as Total_cantidad,SUM(MontoDolaresDes) as Total_dolares")
                   
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->groupBy('idProducto', 'DesProducto')
                    ->orderby('Total_cantidad', 'desc')
                    ->get();


            } else {
                # code...
             

                    $producto = tb_lubricantes::selectRaw("idProducto,DesProducto,estacion,SUM(Cantidad) as Total_cantidad,SUM(MontoDolaresDes) as Total_dolares")
                    ->DatosEstacion()
                    ->whereBetween('Fecha', [$desde, $hasta])
                    ->where('estacion', $request->estacion)
                    ->groupBy('estacion', 'idProducto', 'DesProducto')
                    ->orderby('estacion', 'desc')
                    ->orderby('Total_cantidad', 'desc')
                    ->orderby('Total_dolares', 'desc')
                    ->get();

            }

            $fecha = date('y-m-d');


            $nameExcel = 'Reporte Lubricacion Efectivo-' . $fecha . '.xls';
            //return  response()->json(['data' =>$resultado], 200);

            return Excel::download(
                new LubriConsolidadoExport($producto, 'Reporte General de Desechos'),
                $nameExcel,
                header("Content-Type: application/vnd.ms-excel;")
            );





        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function createreporteExcelLubricantesStockVentas(Request $request)
    {

        //return  response()->json(['data' =>$request->all()], 200);
        try {

            $fecha_actual = date($request->fecha);
            //sumo 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "+ 1 days"));
            //resto 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "- 1 days"));

            # code...
            $desde = date($request->desde);
            $hasta = date($request->hasta);
            $mes = date("m", strtotime($desde));
            $anio = date("Y", strtotime($desde));

            if ($request->estacion == 0) {
                # code...
               
                // $productoVenta = tb_lubricantes_stock_vent::DatosEstacion()->where("mes", intval($mes))
                // ->where("anio", $anio)->orderby('stock', 'desc')->get();
                $productoVenta = tb_lubricantes_stock_vent::selectRaw("mes,anio,SUBSTRING(DesProducto, 1, 6) as codigop,SUM(stock) as stock,SUM(facturado) as facturado,SUM(total) as total")
                ->where("mes", intval($mes))
                ->where("anio", $anio)
                ->groupBy('anio','mes', 'codigop')
                ->orderby('stock', 'desc')
                ->get();

            } else {
                # code...
             

                // $productoVenta = tb_lubricantes_stock_vent::DatosEstacion()->where("mes", intval($mes))
                // ->where("anio", $anio)->where("estacion", $request->estacion)->orderby('stock', 'desc')->get();

                $productoVenta = tb_lubricantes_stock_vent::selectRaw("mes,anio,SUBSTRING(DesProducto, 1, 6) as codigop,SUM(stock) as stock,SUM(facturado) as facturado,SUM(total) as total")
                    ->DatosEstacion()
                    ->where("estacion", $request->estacion)
                    ->where("mes", intval($mes))
                    ->where("anio", $anio)
                    ->groupBy('estacion','anio','mes', 'codigop')
                    ->orderby('stock', 'desc')
                    ->get();
            }

            $fecha = date('y-m-d');


            $nameExcel = 'Reporte Lubricacion Efectivo-' . $fecha . '.xls';
            //return  response()->json(['data' =>$resultado], 200);

            return Excel::download(
                new LubriVentasStockExport($productoVenta, 'Reporte General'),
                $nameExcel,
                header("Content-Type: application/vnd.ms-excel;")
            );





        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }

    public function createreporteExcelLubricantesStockEstacion(Request $request)
    {

        //return  response()->json(['data' =>$request->all()], 200);
        try {

            $fecha_actual = date($request->fecha);
            //sumo 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "+ 1 days"));
            //resto 1 día
            //echo date("d-m-Y", strtotime($fecha_actual . "- 1 days"));

            # code...
            $desde = date($request->desde);
            $hasta = date($request->hasta);
            $mes = date("m", strtotime($desde));
            $anio = date("Y", strtotime($desde));

            if ($request->estacion == 0) {
                # code...
               
                $productoVentaStock = tb_lubricantes_stock_esta::DatosEstacion()->get();


            } else {
                # code...
             
                $productoVentaStock = tb_lubricantes_stock_esta::DatosEstacion()->where("estacion", $request->estacion)->get();

            }

            $fecha = date('y-m-d');


            $nameExcel = 'Reporte Lubricacion Efectivo-' . $fecha . '.xls';
            //return  response()->json(['data' =>$resultado], 200);

            return Excel::download(
                new LubriVentasStockExport($productoVentaStock, 'Reporte General'),
                $nameExcel,
                header("Content-Type: application/vnd.ms-excel;")
            );





        } catch (Exception $e) {
            return response()->json(['data' => $e->getMessage()], 500);
            //throw $th;
        }
    }
}