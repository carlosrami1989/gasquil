//CUANDO SE USA DIRECTORIO VIRTUAL
//export const prefix = "/majoma_sistema";
//CUANDO SE USA SITIO WEB
export const prefix = "";

//export const prefix = "/gestion_mantenimiento/public/Empresa/";

//    'router_prefix' => '/Empresa',