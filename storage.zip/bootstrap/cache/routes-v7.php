<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Bjplcd0SD4QQ5dYB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z39m26TtBerm5wve',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.request',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.email',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ePKiWbh20oweZxw6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/profile-information' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user-profile-information.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'user-password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/confirm-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TNuYQe3XIlrfV9WY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/confirmed-password-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.confirmation',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/two-factor-challenge' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xCj8FfPEKeBEi6Di',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/two-factor-authentication' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.enable',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.disable',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/confirmed-two-factor-authentication' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.confirm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/two-factor-qr-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.qr-code',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/two-factor-secret-key' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.secret-key',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/two-factor-recovery-codes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'two-factor.recovery-codes',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gL1H0EoJhNnYJSmX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/user/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'profile.show',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VUaoY68NdbhJY4uh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/upload-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.upload-file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O8PrpiLlk85sYb8W',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js.map' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Qvj8EnRWCIjSBgvt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/insert_mes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ytJ5mYKG8hi7TXQz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/insert_dia' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5IlCh4EOG8e2N92j',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/insert_gastos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pUlVTcW45IOAIaGS',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/Consulta_mes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PoHp6DExgT1qfBZV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/insert_lubricantes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7hLNXtFx1LvJKT0l',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/insert_lubricantes_stock_estacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::C3cmaGU3ZNGlhAsw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/insert_lubricantes_stock' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8mpNk0cfrhzBPF3y',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yxFomZyAJM3onKVY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/izq' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VJiECKYGlxSvWQje',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/med' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QEpv568VklnptHu1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/der' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z3Ao98FBX8gfX9b0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/test' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::298K0I0l6XXfNzDw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/test2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WP58XtYZHvONf58s',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/prueba' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DoMPgiU6e9f2YWUM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/GetEmpresa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NbWoyqkhJiCgwnkT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/createTarea' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6HFJQ4VvvvKAPhoe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/createSeguimientoTarea' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YjeFjYaCKXdC9sGD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/GetTareas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EAT92MQNi6EoFQLa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/GetTareasNormales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TUcBmJBvQCEcKiwf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/createTareaNormales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WoptfUthatXwHYMY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/api' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::anC6cGiqMmopz4Kv',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/GetApiAcces' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yNEHdAhSPY70DJn5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/cargar_genero' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aNpR497SLaiI86g0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/cargar_provincia' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jX7uKmbAWxsq6qnQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/cargarTipoDesechos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9oEY2T2URXN21Nqg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/crearTipoDesechos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YVYEpc1RSpCfbO8Z',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/cargarClasificacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6p19fLIBKR6jPn7q',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/crearClasificacionDesechos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::mNHfTqCQjMrJfBN1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/cargarClasificacionDescripcion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::054FzMm3lTwxEsiE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/createClasificacionDesechosDescripcion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XTq3D7gxjkLpXQBI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/cargarResponsable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RGj3Fc1H2cIgbwPe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/cargarDepartamento' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tTsMys0vU06RXXiL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/createCInformacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0xRNW8DrUCChkphL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/cargarInformacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dkpwRhUlAONSaB1J',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/usuario' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HUVLljmYq8ZnRP1G',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/usuarioActual' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5lVJnLxEsHg5VPXh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/generacionExcelEstacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7Ryt9cwwsKCdX1Pl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/generacionExcelLubricantes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vb5haQpJ1q8Xg5xP',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/generacionExcelLubricantesConso' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JUGuARgqVFfPZp8p',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/generacionExcelLubricantesStockEstacion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LRnJQnTmgGyDWJpw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/generacionExcelLubricantesStockVentas' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WNfIADHVynY3Aeti',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/graficosPorDia' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hhalDEhHZxuh2TOn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/ConsultaDatos' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wcGAbxFh7iMEreij',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/ConsultaEstaciones' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xxsKPzl0639Jsx8P',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/generacionExcel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oAlfvTaFi7Khi9dY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/generacionPdf' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::driM1kq9mCiN8NoB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/generacionDocumento' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u5cM7R02fc6iRvL7',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/admision/paciente/generacionDocumentoExcel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2ASZUU2eJ9YUTFEc',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/transporte/transporte/GetCliente' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fv7Jdtsa7Cge0fEs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/transporte/transporte/GetDescripcion' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::68U05AfWOl8VafIe',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/transporte/transporte/subir' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XdbfNP9K5r4Knf0H',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/modulos/transporte/transporte/UpdateOrden' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VcSlEZB8W0UY3yhx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/reset\\-password/([^/]++)(*:32)|/livewire/(?|message/([^/]++)(*:68)|preview\\-file/([^/]++)(*:97))|/modulos/(?|admision/paciente/(?|cargar(?|_(?|p(?|ersona/([^/]++)(*:170)|aciente/([^/]++)(*:194))|ciudad/([^/]++)(*:218))|ClasificacionporTipo(?|/([^/]++)(*:259)|Descripcion/([^/]++)/([^/]++)(*:296))|Responsable_de/([^/]++)(*:328)|Departamentoid/([^/]++)(*:359)|Usuario/([^/]++)(*:383))|Get(?|Seguimiento/([^/]++)(*:418)|Mes/([^/]++)/([^/]++)/([^/]++)(*:456)|Dia/([^/]++)(*:476)|EstacionPorDia/([^/]++)(*:507))|IncipSession/([^/]++)(*:537)|Consulta(?|GastosEDS/([^/]++)/([^/]++)/([^/]++)(*:592)|r(?|VendedorPorEstacion/([^/]++)/([^/]++)(*:641)|Reporte/([^/]++)/([^/]++)/([^/]++)(*:683))))|clinico/medico/cargar_sv/([^/]++)(*:727)|transporte/transporte/GetOrden/([^/]++)/([^/]++)/([^/]++)/([^/]++)(*:801))|/(.*)(*:815))/?$}sDu',
    ),
    3 => 
    array (
      32 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      68 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.message',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      97 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.preview-file',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      170 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wNUEmYfmBUKbPSy4',
          ),
          1 => 
          array (
            0 => 'apellidos',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      194 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::G88nDtBC7VsIMdvG',
          ),
          1 => 
          array (
            0 => 'nombre',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      218 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IVAPa6IgFEppd6Cj',
          ),
          1 => 
          array (
            0 => 'idprovincia',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      259 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TXBQuWfVRFqtu3lu',
          ),
          1 => 
          array (
            0 => 'tipo',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      296 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nVoFoUIQN8BgE7aa',
          ),
          1 => 
          array (
            0 => 'tipo',
            1 => 'clasificacion',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      328 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bguUOkoylgJWYowU',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      359 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4yTT2l88NIvfT7eo',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      383 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J0YAgrQY8QDUasR6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      418 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rMpFNYRPY7nggQBN',
          ),
          1 => 
          array (
            0 => 'id_tarea',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      456 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oso74CxkQdK8CZpD',
          ),
          1 => 
          array (
            0 => 'estacion',
            1 => 'mes',
            2 => 'anio',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l1sKgXfmm97fe9r5',
          ),
          1 => 
          array (
            0 => 'estacion',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      507 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ssKSJSQ5bfKkLJtJ',
          ),
          1 => 
          array (
            0 => 'fecha',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      537 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MjjOFIqM1IjA0gbP',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      592 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H4szyuF9EDmnoxs0',
          ),
          1 => 
          array (
            0 => 'estacion',
            1 => 'mes',
            2 => 'anio',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      641 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d9E1lkzZPMssjRvT',
          ),
          1 => 
          array (
            0 => 'mes',
            1 => 'anio',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      683 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3C8lC4dkta3SNaHs',
          ),
          1 => 
          array (
            0 => 'estacion',
            1 => 'fechainicio',
            2 => 'fechafin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      727 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dhKf3f4eZsVrfRCh',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      801 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::V0PR5uRIpib99SFH',
          ),
          1 => 
          array (
            0 => 'fechaini',
            1 => 'fechafin',
            2 => 'orden',
            3 => 'guia',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      815 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TgBT2W4KbBwJ3P4L',
          ),
          1 => 
          array (
            0 => 'any',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Bjplcd0SD4QQ5dYB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Bjplcd0SD4QQ5dYB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@destroy',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\AuthenticatedSessionController@destroy',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.request' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordResetLinkController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordResetLinkController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reset-password/{token}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\NewPasswordController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\NewPasswordController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.email' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordResetLinkController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordResetLinkController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.email',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reset-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\NewPasswordController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\NewPasswordController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\RegisteredUserController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\RegisteredUserController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ePKiWbh20oweZxw6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\RegisteredUserController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\RegisteredUserController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ePKiWbh20oweZxw6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user-profile-information.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'user/profile-information',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\ProfileInformationController@update',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\ProfileInformationController@update',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'user-profile-information.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'user-password.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'user/password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordController@update',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\PasswordController@update',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'user-password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TNuYQe3XIlrfV9WY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/confirm-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmablePasswordController@show',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmablePasswordController@show',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TNuYQe3XIlrfV9WY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirmation' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/confirmed-password-status',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmedPasswordStatusController@show',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmedPasswordStatusController@show',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirmation',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/confirm-password',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmablePasswordController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmablePasswordController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'two-factor-challenge',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticatedSessionController@create',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticatedSessionController@create',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xCj8FfPEKeBEi6Di' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'two-factor-challenge',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest:web',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticatedSessionController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticatedSessionController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xCj8FfPEKeBEi6Di',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.enable' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/two-factor-authentication',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticationController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticationController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.enable',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.confirm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/confirmed-two-factor-authentication',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmedTwoFactorAuthenticationController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\ConfirmedTwoFactorAuthenticationController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.confirm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.disable' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'user/two-factor-authentication',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticationController@destroy',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorAuthenticationController@destroy',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.disable',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.qr-code' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/two-factor-qr-code',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorQrCodeController@show',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorQrCodeController@show',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.qr-code',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.secret-key' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/two-factor-secret-key',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorSecretKeyController@show',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\TwoFactorSecretKeyController@show',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.secret-key',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'two-factor.recovery-codes' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/two-factor-recovery-codes',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\RecoveryCodeController@index',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\RecoveryCodeController@index',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'two-factor.recovery-codes',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gL1H0EoJhNnYJSmX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'user/two-factor-recovery-codes',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
          2 => 'password.confirm',
        ),
        'uses' => 'Laravel\\Fortify\\Http\\Controllers\\RecoveryCodeController@store',
        'controller' => 'Laravel\\Fortify\\Http\\Controllers\\RecoveryCodeController@store',
        'namespace' => 'Laravel\\Fortify\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gL1H0EoJhNnYJSmX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'profile.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'user/profile',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'verified',
        ),
        'uses' => 'Laravel\\Jetstream\\Http\\Controllers\\Livewire\\UserProfileController@show',
        'controller' => 'Laravel\\Jetstream\\Http\\Controllers\\Livewire\\UserProfileController@show',
        'namespace' => 'Laravel\\Jetstream\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'profile.show',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VUaoY68NdbhJY4uh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::VUaoY68NdbhJY4uh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.message' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/message/{name}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\HttpConnectionHandler@__invoke',
        'controller' => 'Livewire\\Controllers\\HttpConnectionHandler',
        'as' => 'livewire.message',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.upload-file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/upload-file',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'controller' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'as' => 'livewire.upload-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.preview-file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/preview-file/{filename}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'controller' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'as' => 'livewire.preview-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::O8PrpiLlk85sYb8W' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'as' => 'generated::O8PrpiLlk85sYb8W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Qvj8EnRWCIjSBgvt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js.map',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'as' => 'generated::Qvj8EnRWCIjSBgvt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ytJ5mYKG8hi7TXQz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/insert_mes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DataController@store_mes',
        'controller' => 'App\\Http\\Controllers\\Api\\DataController@store_mes',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::ytJ5mYKG8hi7TXQz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5IlCh4EOG8e2N92j' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/insert_dia',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DataController@store_dia',
        'controller' => 'App\\Http\\Controllers\\Api\\DataController@store_dia',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::5IlCh4EOG8e2N92j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pUlVTcW45IOAIaGS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/insert_gastos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DataController@store_gastos',
        'controller' => 'App\\Http\\Controllers\\Api\\DataController@store_gastos',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::pUlVTcW45IOAIaGS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PoHp6DExgT1qfBZV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/Consulta_mes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DataController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\DataController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::PoHp6DExgT1qfBZV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7hLNXtFx1LvJKT0l' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/insert_lubricantes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DataController@store_lubricantes',
        'controller' => 'App\\Http\\Controllers\\Api\\DataController@store_lubricantes',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::7hLNXtFx1LvJKT0l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::C3cmaGU3ZNGlhAsw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/insert_lubricantes_stock_estacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DataController@store_lubricantes_estacion',
        'controller' => 'App\\Http\\Controllers\\Api\\DataController@store_lubricantes_estacion',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::C3cmaGU3ZNGlhAsw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8mpNk0cfrhzBPF3y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/insert_lubricantes_stock',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\DataController@store_lubricantes_stock',
        'controller' => 'App\\Http\\Controllers\\Api\\DataController@store_lubricantes_stock',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::8mpNk0cfrhzBPF3y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yxFomZyAJM3onKVY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'transporte',
        ),
        'uses' => 'App\\Http\\Controllers\\AppController@index',
        'controller' => 'App\\Http\\Controllers\\AppController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yxFomZyAJM3onKVY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VJiECKYGlxSvWQje' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'izq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:271:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:53:"function () {
    return \\view(\'auth.izquierda\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000052a736a0000000006fc8be7f";}";s:4:"hash";s:44:"dnXlSfizkRtMN+22ESgIhKndxK+x3VqsrREV2TRXYHE=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::VJiECKYGlxSvWQje',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QEpv568VklnptHu1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'med',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:267:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:49:"function () {
    return \\view(\'auth.medio\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000052a736be000000006fc8be7f";}";s:4:"hash";s:44:"4RWmH5tEwvjeeKESv4b7I3PG6jvqhwTTEkY6ANtIb9Q=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QEpv568VklnptHu1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z3Ao98FBX8gfX9b0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'der',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:269:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:51:"function () {
    return \\view(\'auth.derecha\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000052a736bc000000006fc8be7f";}";s:4:"hash";s:44:"BfnPTs6XYGuqAee6zfkZ4Y4LxnTTS5ofpJygkYAOMRw=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Z3Ao98FBX8gfX9b0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:sanctum',
          2 => 'verified',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:266:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:48:"function () {
    return \\view(\'dashboard\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000052a736b9000000006fc8be7f";}";s:4:"hash";s:44:"61MK+oPLgMZ1v57AOiLKnkCVVVlj7Vjz+KoOyKDZ19g=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'dashboard',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z39m26TtBerm5wve' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@Salir',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@Salir',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Z39m26TtBerm5wve',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::298K0I0l6XXfNzDw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'test',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:270:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:52:"function() {
    return \\view(\'auth.register\');
 }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000052a736ba000000006fc8be7f";}";s:4:"hash";s:44:"3oZyfG/hGHsJNLRgagSRmmDa5ARmFlsDYl39Xx67BeA=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::298K0I0l6XXfNzDw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WP58XtYZHvONf58s' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'test2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:277:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:59:"function() {
    return \\view(\'auth.forgot-password\');
 }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000052a736b5000000006fc8be7f";}";s:4:"hash";s:44:"21vKWC9qnNxftKEAvcUpcw04nhwCGmc9AgwyBrdPsW0=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WP58XtYZHvONf58s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DoMPgiU6e9f2YWUM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'prueba',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:844:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:625:"function(){

 
// Set the redirect URL back to the site to handle the OAuth2 response. This handles both the success and failure journeys.
//$client->setRedirectUri(URL::to(\'/\') . \'/oauth2callback\');

//     $event = new Event;

//     $event->name = \'pueba carlos prueba dos\';
//     $event->description = \'Event description\';
//     $event->startDateTime = Carbon::now();
//     $event->endDateTime = Carbon::now()->addHour();
//     //$event->addScope("https://www.googleapis.com/auth/calendar");
//   $event->addAttendee([\'email\' => \'cramirez@operoil.com\']);
//     $event->save();
//    return $client;
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000052a736b3000000006fc8be7f";}";s:4:"hash";s:44:"6Do0QoidH0J6QOnKCMj9PQOR6RN5bIdKVKZ9qLjH2bU=";}}',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::DoMPgiU6e9f2YWUM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NbWoyqkhJiCgwnkT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/GetEmpresa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@GetEmpresa',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@GetEmpresa',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::NbWoyqkhJiCgwnkT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wNUEmYfmBUKbPSy4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargar_persona/{apellidos}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PersonaController@ConsultarPersona',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PersonaController@ConsultarPersona',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::wNUEmYfmBUKbPSy4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6HFJQ4VvvvKAPhoe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/createTarea',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@createTarea',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@createTarea',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::6HFJQ4VvvvKAPhoe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YjeFjYaCKXdC9sGD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/createSeguimientoTarea',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\SeguimientoController@createSeguimientoTarea',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\SeguimientoController@createSeguimientoTarea',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::YjeFjYaCKXdC9sGD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EAT92MQNi6EoFQLa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/GetTareas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@GetTareas',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@GetTareas',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::EAT92MQNi6EoFQLa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TUcBmJBvQCEcKiwf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/GetTareasNormales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@GetTareasNormales',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@GetTareasNormales',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::TUcBmJBvQCEcKiwf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WoptfUthatXwHYMY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/createTareaNormales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@createTareaNormales',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\TareasController@createTareaNormales',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::WoptfUthatXwHYMY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rMpFNYRPY7nggQBN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/GetSeguimiento/{id_tarea}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\SeguimientoController@GetSeguimiento',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\SeguimientoController@GetSeguimiento',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::rMpFNYRPY7nggQBN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::anC6cGiqMmopz4Kv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/api',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\SeguimientoController@GetApi',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\SeguimientoController@GetApi',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::anC6cGiqMmopz4Kv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yNEHdAhSPY70DJn5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/GetApiAcces',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\SeguimientoController@GetApiAcces',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\SeguimientoController@GetApiAcces',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::yNEHdAhSPY70DJn5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::G88nDtBC7VsIMdvG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargar_paciente/{nombre}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PacienteController@ConsultarPaciente',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PacienteController@ConsultarPaciente',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::G88nDtBC7VsIMdvG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aNpR497SLaiI86g0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargar_genero',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PacienteController@consultargenero',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PacienteController@consultargenero',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::aNpR497SLaiI86g0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jX7uKmbAWxsq6qnQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargar_provincia',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PacienteController@consultarProvincia',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PacienteController@consultarProvincia',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::jX7uKmbAWxsq6qnQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IVAPa6IgFEppd6Cj' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargar_ciudad/{idprovincia}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PacienteController@consultarciudad',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\PacienteController@consultarciudad',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::IVAPa6IgFEppd6Cj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9oEY2T2URXN21Nqg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarTipoDesechos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultar',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultar',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::9oEY2T2URXN21Nqg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YVYEpc1RSpCfbO8Z' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/crearTipoDesechos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@create',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@create',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::YVYEpc1RSpCfbO8Z',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6p19fLIBKR6jPn7q' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarClasificacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarClasificacion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarClasificacion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::6p19fLIBKR6jPn7q',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::mNHfTqCQjMrJfBN1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/crearClasificacionDesechos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createClasificacionDesechos',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createClasificacionDesechos',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::mNHfTqCQjMrJfBN1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::054FzMm3lTwxEsiE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarClasificacionDescripcion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarClasificacionDescripcion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarClasificacionDescripcion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::054FzMm3lTwxEsiE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TXBQuWfVRFqtu3lu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarClasificacionporTipo/{tipo}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarClasificacionPorTipo',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarClasificacionPorTipo',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::TXBQuWfVRFqtu3lu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nVoFoUIQN8BgE7aa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarClasificacionporTipoDescripcion/{tipo}/{clasificacion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarClasificacionPorDescripcion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarClasificacionPorDescripcion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::nVoFoUIQN8BgE7aa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XTq3D7gxjkLpXQBI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/createClasificacionDesechosDescripcion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createClasificacionDesechosDescripcion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createClasificacionDesechosDescripcion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::XTq3D7gxjkLpXQBI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RGj3Fc1H2cIgbwPe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarResponsable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarResponsable',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarResponsable',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::RGj3Fc1H2cIgbwPe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bguUOkoylgJWYowU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarResponsable_de/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarResponsableDepar',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarResponsableDepar',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::bguUOkoylgJWYowU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tTsMys0vU06RXXiL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarDepartamento',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarDepartamento',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarDepartamento',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::tTsMys0vU06RXXiL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4yTT2l88NIvfT7eo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarDepartamentoid/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarDepartamentoid',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@consultarDepartamentoid',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::4yTT2l88NIvfT7eo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0xRNW8DrUCChkphL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/createCInformacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createInformacion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createInformacion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::0xRNW8DrUCChkphL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J0YAgrQY8QDUasR6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarUsuario/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@Consultarusuario',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@Consultarusuario',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::J0YAgrQY8QDUasR6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dkpwRhUlAONSaB1J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/cargarInformacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@ConsultarInformacion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@ConsultarInformacion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::dkpwRhUlAONSaB1J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MjjOFIqM1IjA0gbP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/IncipSession/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@IncipSession',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@IncipSession',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::MjjOFIqM1IjA0gbP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HUVLljmYq8ZnRP1G' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/usuario',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@User',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@User',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::HUVLljmYq8ZnRP1G',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5lVJnLxEsHg5VPXh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/usuarioActual',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarUsuario',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarUsuario',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::5lVJnLxEsHg5VPXh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oso74CxkQdK8CZpD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/GetMes/{estacion}/{mes}/{anio}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarMes',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarMes',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::oso74CxkQdK8CZpD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l1sKgXfmm97fe9r5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/GetDia/{estacion}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarDia',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarDia',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::l1sKgXfmm97fe9r5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ssKSJSQ5bfKkLJtJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/GetEstacionPorDia/{fecha}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarDiaPorEstacion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarDiaPorEstacion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::ssKSJSQ5bfKkLJtJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7Ryt9cwwsKCdX1Pl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/generacionExcelEstacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcel',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcel',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::7Ryt9cwwsKCdX1Pl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Vb5haQpJ1q8Xg5xP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/generacionExcelLubricantes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcelLubricantes',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcelLubricantes',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::Vb5haQpJ1q8Xg5xP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JUGuARgqVFfPZp8p' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/generacionExcelLubricantesConso',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcelLubricantesConsolidado',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcelLubricantesConsolidado',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::JUGuARgqVFfPZp8p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LRnJQnTmgGyDWJpw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/generacionExcelLubricantesStockEstacion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcelLubricantesStockEstacion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcelLubricantesStockEstacion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::LRnJQnTmgGyDWJpw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WNfIADHVynY3Aeti' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/generacionExcelLubricantesStockVentas',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcelLubricantesStockVentas',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@createreporteExcelLubricantesStockVentas',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::WNfIADHVynY3Aeti',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hhalDEhHZxuh2TOn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/graficosPorDia',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarInformacion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarInformacion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::hhalDEhHZxuh2TOn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wcGAbxFh7iMEreij' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/ConsultaDatos',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarDatos',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarDatos',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::wcGAbxFh7iMEreij',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xxsKPzl0639Jsx8P' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/ConsultaEstaciones',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarEstaciones',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarEstaciones',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::xxsKPzl0639Jsx8P',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H4szyuF9EDmnoxs0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/ConsultaGastosEDS/{estacion}/{mes}/{anio}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarGastosEDS',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarGastosEDS',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::H4szyuF9EDmnoxs0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d9E1lkzZPMssjRvT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/ConsultarVendedorPorEstacion/{mes}/{anio}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarVendedorPorEstacion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarVendedorPorEstacion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::d9E1lkzZPMssjRvT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3C8lC4dkta3SNaHs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/ConsultarReporte/{estacion}/{fechainicio}/{fechafin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarReporte',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\Dashboard@ConsultarReporte',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::3C8lC4dkta3SNaHs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oAlfvTaFi7Khi9dY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/generacionExcel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@generacionExcel',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@generacionExcel',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::oAlfvTaFi7Khi9dY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::driM1kq9mCiN8NoB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/admision/paciente/generacionPdf',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@generacionPDF',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@generacionPDF',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::driM1kq9mCiN8NoB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::u5cM7R02fc6iRvL7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/generacionDocumento',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createreporte',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createreporte',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::u5cM7R02fc6iRvL7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2ASZUU2eJ9YUTFEc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/admision/paciente/generacionDocumentoExcel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'administracion',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createreporteExcel',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Administracion\\tipo_desechos@createreporteExcel',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Administracion',
        'prefix' => 'modulos/admision/paciente',
        'where' => 
        array (
        ),
        'as' => 'generated::2ASZUU2eJ9YUTFEc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dhKf3f4eZsVrfRCh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/clinico/medico/cargar_sv/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'clinico',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Medico\\ControlClinico@ConsultarSignosVitales',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Medico\\ControlClinico@ConsultarSignosVitales',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Medico',
        'prefix' => 'modulos/clinico/medico',
        'where' => 
        array (
        ),
        'as' => 'generated::dhKf3f4eZsVrfRCh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fv7Jdtsa7Cge0fEs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/transporte/transporte/GetCliente',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'transporte',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@ConsultarCliente',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@ConsultarCliente',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Transporte',
        'prefix' => 'modulos/transporte/transporte',
        'where' => 
        array (
        ),
        'as' => 'generated::fv7Jdtsa7Cge0fEs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::68U05AfWOl8VafIe' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/transporte/transporte/GetDescripcion',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'transporte',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@ConsultarDescripcion',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@ConsultarDescripcion',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Transporte',
        'prefix' => 'modulos/transporte/transporte',
        'where' => 
        array (
        ),
        'as' => 'generated::68U05AfWOl8VafIe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XdbfNP9K5r4Knf0H' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/transporte/transporte/subir',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'transporte',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@UploadGuias',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@UploadGuias',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Transporte',
        'prefix' => 'modulos/transporte/transporte',
        'where' => 
        array (
        ),
        'as' => 'generated::XdbfNP9K5r4Knf0H',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::V0PR5uRIpib99SFH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'modulos/transporte/transporte/GetOrden/{fechaini}/{fechafin}/{orden}/{guia}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'transporte',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@GetConsultarOrden',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@GetConsultarOrden',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Transporte',
        'prefix' => 'modulos/transporte/transporte',
        'where' => 
        array (
        ),
        'as' => 'generated::V0PR5uRIpib99SFH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VcSlEZB8W0UY3yhx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'modulos/transporte/transporte/UpdateOrden',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'transporte',
          1 => 'auth:web',
        ),
        0 => 'verified',
        'uses' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@UpdateComplemento',
        'controller' => 'App\\Http\\Controllers\\Modulos\\Transporte\\CalidadFlotaController@UpdateComplemento',
        'namespace' => 'App\\Http\\Controllers\\Modulos\\Transporte',
        'prefix' => 'modulos/transporte/transporte',
        'where' => 
        array (
        ),
        'as' => 'generated::VcSlEZB8W0UY3yhx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TgBT2W4KbBwJ3P4L' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '{any}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'transporte',
        ),
        'uses' => 'App\\Http\\Controllers\\AppController@index',
        'controller' => 'App\\Http\\Controllers\\AppController@index',
        'namespace' => 'App\\Http\\Controllers',
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TgBT2W4KbBwJ3P4L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'any' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
