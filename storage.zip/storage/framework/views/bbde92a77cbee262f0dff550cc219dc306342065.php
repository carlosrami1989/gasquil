 
  
 
<table class="configTableCaberaAll configBorderItem configTextItem2 topCabecera" >
    <tr class="cabeceras" >
        <td>Nº</td>
        <td>ESTACION</td>
        <td>DesProducto</td>
        <td>Cantidad</td>
          <td>Monto Dolares Des</td>
     
        
    </tr>
    <?php
    $cont = 0;
    ?>
    <?php for($i=0; $i < sizeof($lista) ; $i++): ?> <tr>
        <?php
        $cont = $i;
        $cont +=1;

        ?>
        <td   > <?php echo e($cont); ?></td>
        <td > <?php echo e($lista[$i]->des_estacion); ?></td>
        <td > <?php echo e($lista[$i]->DesProducto); ?></td>
      
        <td > <?php echo e($lista[$i]->Total_cantidad); ?></td>
        <td > <?php echo e($lista[$i]->Total_dolares); ?></td>
 
       
        </tr>

        <?php endfor; ?>


</table>




<table style="position: fixed;bottom: 0px;">
    <thead>
        <tr>
            
        </tr>
    </thead>
</table>


 <?php /**PATH C:\Users\Carlos Ramirez\Documents\SISTEMAS 2022\DESARROLLOS\copedesara\resources\views/reports/lubricante_consolidado.blade.php ENDPATH**/ ?>