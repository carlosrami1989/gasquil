 
  
 
<table class="configTableCaberaAll configBorderItem configTextItem2 topCabecera" >
    <tr class="cabeceras" >
        <td>Nº</td>
        <td>ESTACION</td>
        <td>Cliente</td>
        <td>Fecha </td>
        <td>Monto de Dolares</td>
        <td>Numero de Factura</td>
        <td>Vendedor</td>
        <td>DesProducto</td>
        <td>Cantidad</td>
        <td>Precio</td>
        <td>Monto Dolares Des</td>
        <td>Fecha Actualizacion</td>       
        
    </tr>
    <?php
    $cont = 0;
    ?>
    <?php for($i=0; $i < sizeof($lista) ; $i++): ?> <tr>
        <?php
        $cont = $i;
        $cont +=1;

        ?>
        <td   > <?php echo e($cont); ?></td>
        <td > <?php echo e($lista[$i]->des_estacion); ?></td>
               <td > <?php echo e($lista[$i]->Nombre); ?></td>
        <td > <?php echo e($lista[$i]->Fecha); ?> </td>
        <td > <?php echo e($lista[$i]->MontoDolares); ?></td>
        <td > <?php echo e($lista[$i]->numerofactura); ?></td>
        <td > <?php echo e($lista[$i]->Vendedor); ?></td>
        <td > <?php echo e($lista[$i]->DesProducto); ?></td>
        <td > <?php echo e($lista[$i]->Cantidad); ?></td>
        <td > <?php echo e($lista[$i]->Precio); ?></td>
        <td > <?php echo e($lista[$i]->MontoDolaresDes); ?></td>
        <td > <?php echo e($lista[$i]->created_at); ?></td>
       
        </tr>

        <?php endfor; ?>


</table>




<table style="position: fixed;bottom: 0px;">
    <thead>
        <tr>
            
        </tr>
    </thead>
</table>


 <?php /**PATH C:\Users\Carlos Ramirez\Documents\SISTEMAS 2022\DESARROLLOS\copedesara\resources\views/reports/lubricante_reporte.blade.php ENDPATH**/ ?>