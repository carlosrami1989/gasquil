 
  
 
<table class="configTableCaberaAll configBorderItem configTextItem2 topCabecera" >
    <tr class="cabeceras" >
        <td>Nº</td>
        <td>ESTACION</td>
        <td>Descripcion</td>
        <td>stock </td>
        
        
    </tr>
    <?php
    $cont = 0;
    ?>
    <?php for($i=0; $i < sizeof($lista) ; $i++): ?> <tr>
        <?php
        $cont = $i;
        $cont +=1;

        ?>
        <td   > <?php echo e($cont); ?></td>
        <td > <?php echo e($lista[$i]->des_estacion); ?></td>
               <td > <?php echo e($lista[$i]->Descripcion); ?></td>
        <td > <?php echo e($lista[$i]->Cantidad); ?> </td>
        
       
       
        </tr>

        <?php endfor; ?>


</table>




<table style="position: fixed;bottom: 0px;">
    <thead>
        <tr>
            
        </tr>
    </thead>
</table>


 <?php /**PATH C:\Users\Carlos Ramirez\Documents\SISTEMAS 2022\DESARROLLOS\copedesara\resources\views/reports/lubricantes_stock.blade.php ENDPATH**/ ?>