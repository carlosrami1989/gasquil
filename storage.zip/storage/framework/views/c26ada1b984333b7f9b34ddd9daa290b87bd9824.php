 
  
 
<table class="configTableCaberaAll configBorderItem configTextItem2 topCabecera" >
    <tr class="cabeceras" >
        <td>Nº</td>
        <td>ESTACION</td>
        <td>Fecha </td>
        <td>Monto Total Efectivo</td>
        <td>Monto Total Galones</td>
       
        
    </tr>
    <?php
    $cont = 0;
    ?>
    <?php for($i=0; $i < sizeof($lista) ; $i++): ?> <tr>
        <?php
        $cont = $i;
        $cont +=1;

        ?>
        <td   > <?php echo e($cont); ?></td>
        <td > <?php echo e($lista[$i]->des_estacion); ?></td>
               <td > <?php echo e($lista[$i]->dia); ?></td>
        <td > <?php echo e($lista[$i]->total_dolares); ?> </td>
        <td > <?php echo e($lista[$i]->galones); ?></td>
       
        </tr>

        <?php endfor; ?>


</table>




<table style="position: fixed;bottom: 0px;">
    <thead>
        <tr>
            
        </tr>
    </thead>
</table>


 <?php /**PATH C:\Users\Carlos Ramirez\Documents\SISTEMAS 2022\DESARROLLOS\copedesara\resources\views/reports/excel_excel.blade.php ENDPATH**/ ?>